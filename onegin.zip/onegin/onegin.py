import requests
import openpyxl
import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import *
import webbrowser


wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Risk Check Results"
ws.append(["Link", "Risk Level", "Risk Name"])

def save_file():
    save_path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel files", "*.xlsx")])
    if save_path:
        wb.save(save_path)

def make_api_request(api_url, api, key, url):
    full_url = f"{api_url}?api={api}&key={key}&url={url}"
    response = requests.get(full_url)

    if response.status_code == 200:
        response_data = response.json()
        risk_value = response_data.get('risk')
        level = response_data.get('level')
        return url, risk_value,level
    else:
        return url, f'Ошибка: {response.status_code}'

def browse_file():
    file_path = filedialog.askopenfilename()
    entry_file.delete(0, tk.END)
    entry_file.insert(0, file_path)

def process_data():
    k = entry_file.get()
    with open(k, "r") as file:
        data = file.readlines()

    key = entry_key.get()

    api_url = 'https://turgenev.ashmanov.com/'
    api = 'risk'

    for url in data:
        link_result, risk_level_result,level_result = make_api_request(api_url, api, key, url.strip())
        ws.append([link_result, risk_level_result, level_result])

    try:
        save_path = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel files", "*.xlsx")])
        if save_path:
            wb.save(save_path)
        messagebox.showinfo("Успех", "Файл успешно сохранен")
    except PermissionError:
        messagebox.showerror("Ошибка", "Не удалось сохранить файл. Проверьте права доступа к директории.")



def open_help():
    webbrowser.open("https://t.me/r_search")

def open_money():
    webbrowser.open("https://yoomoney.ru/to/410015573611007")

root = tk.Tk()
root.title("Евгений Онегин")
root.geometry("420x400")
root.resizable(width=False,height=False)
root.configure(background='grey')
img=PhotoImage(file='icons8-seo-64.png')
root.iconphoto(False,img)

label_file = tk.Label(root, text="Введите путь к файлу:")
label_file.pack()

entry_file = tk.Entry(root)
entry_file.pack()

frame_file = tk.Frame(root)
frame_file.pack(pady=1)

button_browse = tk.Button(root, text="Обзор", command=browse_file)
button_browse.pack()

frame_browse = tk.Frame(root)
frame_browse.pack(pady=12)



label_key = tk.Label(root, text="Введите ключ API:")
label_key.pack()

entry_key = tk.Entry(root)
entry_key.pack()

#def func():
#    entry.insert(0, pyperclip.paste)
#entry = tk.Entry(root)
#entry.pack()
#btn = tk.Button(text='paste', command=func).pack()


frame_key = tk.Frame(root)
frame_key.pack(pady=1)

button_process = tk.Button(root, text="Обработать данные", command=process_data)
button_process.pack()

frame_help = tk.Frame(root)
frame_help.pack(pady=12)

button_help = tk.Button(root, text="Помощь", command=open_help)
button_help.place(x=90,y=300)
#button_help.pack()

button_money = tk.Button(root, text="Поддержать автора :)", command=open_money)
button_money.place(x=210,y=300)



root.mainloop()
